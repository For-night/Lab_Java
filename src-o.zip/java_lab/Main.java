package java_lab;

import java.util.ArrayList;

public class Main {
	public static void main(String [] args) {
//		System.out.print("hello world!"  );
//		long l = System.currentTimeMillis();
//		Solution s = new Solution();
//		double [] ans = s.dicesProbability(2);
//		
//		for(double d : ans) {
//			System.out.println("ans : " + d);
//		}
//		System.out.print("��ʱ��" + (System.currentTimeMillis() - l));
		
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(1);
		al.add(255);
		if(al.contains(255))
			System.out.print("you 255");
	}
}

/*
 

 */
